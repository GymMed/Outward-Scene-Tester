## Changelog

### Release 0.0.2 Version

#### Added

-   Added descriptions to events.

#### Fixed

-   Fixed readme code blocks.
-   Updated Mods Communicator dependency

### Release 0.0.1 Version

-   Initial release.
